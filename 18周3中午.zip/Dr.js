// JavaScript Document
//敌人
var Dr=function(_x,_y,_s,_p)
{
	this.type="Dr";
	this.x=_x;
	this.y=_y;
	this.w=20;
	this.h=20;
	this.s=_s;
	this.img=new Image(); //记录它的图片
	this.img.src=_p;
	//每秒执行60次
	this.update=function(t)
	{
		this.x-=this.s;
		if (this.x<0) this.parent.remove(this); 
	}
	//碰撞到了
	this.hit=function(obj)
	{

	}
}
Dr.prototype=new Jl();