// JavaScript Document
//子弹类
var WjZd=function(_x,_y,_s,_p)
{
	this.type="WjZd";
	this.x=_x;
	this.y=_y;
	this.w=5;
	this.h=5;
	this.s=_s;
	this.img=new Image(); //记录它的图片
	this.img.src=_p;
	//每秒执行60次
	this.update=function(t)
	{
		this.x+=this.s;
		if (this.x>this.parent.parent.w) this.parent.remove(this);
	}
	//碰撞到了
	this.hit=function(obj)
	{
		if (obj.type=="Wj") return; //打到如果是玩家，就跳出不处理
		if (obj.type=="WjZd") return; //打到如果是玩家子弹，就跳出不处理
		if (obj.type=="Dr")
		{
			this.parent.remove(obj);  //删除撞到那个
			this.parent.remove(this); //删除掉自己
		}
		
	}
}
WjZd.prototype=new Jl();