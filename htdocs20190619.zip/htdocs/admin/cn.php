<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "toys";
     
    // 创建连接
    $cn = new mysqli($servername, $username, $password, $dbname);


function getKjm($filename){ 
  $myext = substr($filename, strrpos($filename, '.')); 
  return str_replace('.','',$myext); 
}

?>